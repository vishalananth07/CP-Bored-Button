# Bored Button
A python script which randomly opens a CP problem according to user difficulty  

## Requirements
pip3

## Installing the package
```
pip3 install cpboredbutton
```

## Running the File
Run the script with  
```
cpboredbutton [-cf Codeforces_Handle]
```

## Completed
* Implemented for Codeforces

## Next Steps
* Move Codeforces functions to class
* Expand to Codechef, Hackerrank & SPOJ
* Front-End service
* API Service

